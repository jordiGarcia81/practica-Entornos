﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using practica.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica.Common.Tests
{
    [TestClass()]
    public class TemperaturaTests
    {
        [TestMethod()]
        public void CelsiusToFahrenheitTest()
        {
            //Arrange
            var expected = 91.4;

            //Act
            var actual = Temperatura.CelsiusToFahrenheit();

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}