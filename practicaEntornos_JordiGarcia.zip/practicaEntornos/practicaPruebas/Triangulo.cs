﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica
{
    /// <summary>
    /// Determina el tipo de triangulo segun sus lados
    /// </summary>
    public class Triangulo
    {

        public Triangulo()
        {
            Console.WriteLine("introduce el primer lado del triangulo: ");
            lado1 = int.Parse(Console.ReadLine());
            Console.WriteLine("introduce el segundo lado del triangulo: ");
            lado2 = int.Parse(Console.ReadLine());
            Console.WriteLine("introduce el tercer lado del triangulo: ");
            lado3 = int.Parse(Console.ReadLine());
        }

        public Triangulo(int lado1, int lado2, int lado3)
        {

            this.lado1 = lado1;
            this.lado2 = lado2;
            this.lado3 = lado3;
            tipo = CalcularTipo();


        }


        private string tipo;

        public string Tipo {
            get { return tipo; }
            set { tipo = value; }
        }

        private int lado1;

        public int Lado1 {
            get { return lado1; }
            set { lado1 = value; }
        }
        private int lado2;
        public int Lado2
        {
            get { return lado2; }
            set { lado1 = value; }
        }

        private int lado3;

        public int Lado3
        {
            get { return lado3; }
            set { lado1 = value; }
        }


        public string CalcularTipo()
        {
            if (lado1 == lado2 && lado1 == lado3 && lado2 == lado3)
            {
                return "equilatero";
            }
            else if (lado1 != lado2 && lado1 != lado3 && lado2 != lado3)
            {
                return "escaleno";
            }
            else
            {
                return "isosceles";
            }



        }

        public void Informa()
        {
            Console.WriteLine("el primer lado es: {0}  el segundo lado es: {1}" +
                "  el tercer lado es: {2}", lado1, lado2, lado3);

        }


    }

}
