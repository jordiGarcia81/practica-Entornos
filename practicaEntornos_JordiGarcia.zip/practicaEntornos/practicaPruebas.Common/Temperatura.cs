﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica.Common
{

    /// <summary>
    /// conversor de temperatura de grados celsius a fahrenheit y viceversa
    /// </summary>
    /// <param name="celsius">grados celsius</param>
    /// <param name="fahrenheit">grados fahrenheit</param>
    /// <returns>resultado de la conversion de ambos grados</returns>
    public static class Temperatura
    {
        public static double CelsiusToFahrenheit()
        {
            
            double celsius = 33;

           
            double fahrenheit = (celsius * 9 / 5) + 32;

            return fahrenheit;
        }

        public static double FahrenheitToCelsius()
        {
           
            double fahrenheit = 57;

          
            double celsius = (fahrenheit - 32) * 5 / 9;

            return celsius;
        }
    }
}
