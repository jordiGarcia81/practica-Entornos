﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using practica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica.Biz.Tests
{
    [TestClass()]
    public class TrianguloTests
    {
        [TestMethod()]
        public void CalcularTipoTest()
        {
            //Arrange
            var triangulo = new Triangulo();
            triangulo.Lado1 = 21;
            triangulo.Lado2 = 21;
            triangulo.Lado3 = 21;

            var expected = "equilatero";

            //Act
            var actual = triangulo.CalcularTipo();

            //Assert
            Assert.AreEqual(expected,actual);
        }

        [TestMethod()]
        public void CalcularTipoTest_ConstructorParametros()
        {
            //Arrange
            var triangulo = new Triangulo(21,21,21);
           

            var expected = "equilatero";

            //Act
            var actual = triangulo.CalcularTipo();

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}